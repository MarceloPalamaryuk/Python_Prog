nums = [1,8,5,12,23,7]
mochila = ["Bomba", "ak47", "Glock", "C4"]
msg = ""
# Adicionar um elemento no final da lista 
for ferramenta in mochila:
    print(ferramenta, end = ", ") 
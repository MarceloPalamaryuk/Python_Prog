num1 = int(input("Digita o primeiro valor: "))
num2 = int(input("Digita o primeiro valor: "))
soma = num1+num2
media = int((num1+num2)/2)
print(f"\nSoma = {soma}")
print(f"Media = {media}")



comprimento = float(input("Digite o comprimento do retangulo: "))
largura= float(input("Digite o largura do retangulo: "))
area = comprimento*largura
perimetro = (comprimento*2)+(largura*2)

print(f"A area é {area}.")
print(f"A area é {perimetro}.")



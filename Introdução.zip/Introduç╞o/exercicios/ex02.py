nums = [1,2,3,4,5,6,7,8,9,10]
#for i in nums:
#    if (nums[i]/2) != int(nums[i]/2):
#        print(i, end = ", ")

for i in nums:
    if nums[i-1]%2 == 0:
        print(i)
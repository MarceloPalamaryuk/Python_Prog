produtos = {"CalçasSupreme": 15.60, "Mochila": 10.99, "Bone": 5.05}
soma = 0
maximo = 0
produto_mais_caro = ""

for p, v in produtos.items():
    soma = soma + v
    if v > maximo:
        maximo = v
        produto_mais_caro = p

media = soma / len(produtos)
print(f"O produto mais caro é {produto_mais_caro}.\nMédia dos preços = {media:.2f}")
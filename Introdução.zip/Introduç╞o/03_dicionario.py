idades_alunos = {"Rui": 17, "Ana": 19, "Carlos": 21}
#for nome in idades_alunos.keys():
#    print(nome)

#for idade in idades_alunos.values():
#    print(idade)

for k,v in idades_alunos.items():
    print(f"O(A) aluno(a) {k} tem {v} anos.")

import os
"""
caminho = "ficheiros/dados.txt"

if os.path.exists(caminho):
    f = open(caminho, "r")
else:
    f = open(caminho, "w")

f.close()

with open(caminho, "w") as f:
    f.write("Primeira linha do ficheiro\n")
    f.write("Segunda linha do ficheiro\n")
    f.write("Terceira linha do ficheiro")
    
with open(caminho, "r") as f:
    texto = f.read()
    #texto2 = f.readline()
    #texto3 = f.readlines()
    #texto3 = [texto3.strip() for texto in texto3]
    print(texto)

lista_palavras: list[str] = ["\nABC","\nDEF","\nGHI"]
with open(caminho, "a") as f:
    f.writelines(lista_palavras)
f.close()
"""
"""import csv

with open('ficheiros/dados.txt', mode='r', newline='', encoding='utf-8') as ficheiro_csv:
    leitor = csv.reader(f)
    for linha in leitor:
"""

import json

res = "a a a a a a a a A b b b b bb n n n n n k "
portuacoes = ".,:;"
for pontuacao in portuacoes:
    res = res.replace (pontuacao, '')
lista = res.split()

dicionario = {}
print('---------------------------------------------------------------------')
print("Frequencia: ")
#ex1
for palavra in lista:
    if palavra.lower() in dicionario.keys():
        dicionario[palavra.lower()] += 1
    else:
        dicionario[palavra.lower()] = 1

print(dicionario)

#ex2
dicaux = sorted(dicionario.items(), key=lambda item: item[1],reverse=True)

print('---------------------------------------------------------------------')
print("5 Palavras mais usadas: ")
for palavra in range(0,4):
    print(dicaux[palavra])

#ex3

print('---------------------------------------------------------------------')
print("Infos: ")

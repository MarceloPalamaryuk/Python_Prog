biblioteca = {
    "livro1": {
        "titulo": "Python Fluente",
        "autor": "Luciano Ramalho",
        "ano": 2015,
        "disponivel": True
    },
    "livro2": {
        "titulo": "Pense em Python",
        "autor": "Allen B. Downey",
        "ano": 2012,
        "disponivel": False
    },
    "livro3": {
        "titulo": "Introdução à Programação com Python",
        "autor": "Allen B. Downey",
        "ano": 2019,
        "disponivel": True
    }
}

#ex1
biblioteca["livro4"] = {"titulo": "Listas Python", "autor": "Luciano Ramalho", "ano": 2015, "disponivel": True}

#ex2
#for c in biblioteca.keys():
    #print(biblioteca[c]["titulo"])

#ex3
biblioteca["livro1"]["disponivel"] = False
#print(biblioteca["livro1"]["disponivel"])

#ex4
def livro_por_autor(x):
    lista = []
    for c in biblioteca.keys():
        if biblioteca[c]["autor"] == x:
            lista.append(biblioteca[c]["titulo"])
    return lista

resposta = livro_por_autor("Allen B. Downey")
print(resposta)
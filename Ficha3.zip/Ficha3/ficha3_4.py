#ex1
nums = {n: n*n for n in range(1,11)}

#ex2
lista_palavras = ["Maça", "Antonio", "Escavadora Boing 300X Blindada"]

d1 = {palavra: len(palavra) for palavra in lista_palavras}

#ex3
notas = {"Ana": 18, "Bruno": 15, "Carla": 17,"David": 12, "Eva": 19}
alunos_bons = {aluno: nota for aluno,nota in notas.items() if nota >= 15}
print(alunos_bons)

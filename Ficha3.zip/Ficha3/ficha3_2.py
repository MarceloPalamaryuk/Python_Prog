def contar_caracteres(x):
    lista = {}
    for c in x:
        if c in lista.keys():
            lista[c] += 1
        else:
            lista[c] = 1
    return lista

resultado = contar_caracteres("explotano")
print(resultado)
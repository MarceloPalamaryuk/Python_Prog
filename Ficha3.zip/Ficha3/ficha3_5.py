inventario = {}
def menu():
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("   \\\\\\\Selecione um operação://///\n")
    print("---------------------------")
    print("1 : Adicionar Produto")
    print("---------------------------")
    print("2 : Atualizar Quantidade")
    print("---------------------------")
    print("3 : Remover Produto")
    print("---------------------------")
    print("4 : Mostrar Produtos Por valor")
    print("---------------------------")
    print("5 : Calcular Valor Total")
    print("---------------------------")
    print("6 : Sair do Programa")
    print("---------------------------")

def adicionar_produto(inv):
    nome = input("Nome do produto: ")
    if nome in inv.keys():
        return inv
    inv[nome] = {}
    inv[nome]['qtde'] = int(input("Quantidade: "))
    inv[nome]['preço'] = float(input("Preço: "))
    return inv

print(inventario)

def atualizar(inv, qt):
    produto = input("Nome do produto atualizado: ")
    inv[produto]['qtde'] = qt
    return inv

def remover(inv):
    produto = input("Nome do produto: ")
    if produto not in inv.keys():
        return inv
    del inv[produto]
    return inv

def abaixo(inv, qt):
    for produto, dados in inv.items():
        if dados['qtde'] < qt:
            print(produto)

def valortotal(inv):
    total = 0
    for dados in inv.values():
        total += dados['qtde'] * dados['preço']
    return total

programa_ativo = True

while programa_ativo == True:
    menu()
    resposta = input()
    if resposta == "6":
        programa_ativo = False
    elif resposta == "1":
        adicionar_produto(inventario)
    elif resposta == "2":
        nome_quantidade = int(input("Atualizar quantidade: "))   
        inventario = atualizar(inventario, nome_quantidade)
    elif resposta == "3":
        remover(inventario)
    elif resposta == "4":
        res = int(input("Quantidade: "))
        abaixo(inventario, res)
    elif resposta == "5":
        print(valortotal(inventario))
    else:
        print("Es burro ou fazes-te?")

print(inventario)
print("O programa terminou sem erro!")


aluno = dict(Nome="Ana Silva",Idade=17,Disciplinas=['Mat','fi','inf'],Notas={"Matemática": 18, "Física": 17, "Informática": 19})
#ex1
aluno["Disciplinas"].append("Pt")
aluno["Notas"]["Pt"] = 16

#ex2
aluno["Idade"] = 18

#ex3
print(aluno["Notas"])

#ex4
soma = sum(aluno["Notas"].values())
#soma = 0
#for s in aluno["Notas"].values():
#    soma += s
    
media = soma / len(aluno["Notas"])
print(f"A media das notas da {aluno['Nome']} é: {media:.1f}")

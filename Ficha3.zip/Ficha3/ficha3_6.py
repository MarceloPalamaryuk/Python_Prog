estudantes = {"Ana": 18, "Carlos": 15, "Bruno": 17, "Diana": 19,
"Eva": 14}
#ex1
lista1 = dict(sorted(estudantes.items()))
#ex2
lista2 = sorted(estudantes.items(), key=lambda item: item[1],reverse=True)
#ex3
def ordenar(dic, tipo):
    res = {}
    if tipo==1:
        res = sorted(dic.items())
    elif tipo==2:
        res = sorted(estudantes.items(), key=lambda item: item[1],reverse=True)
    else: return "Nada"
    return res   
print(ordenar(estudantes, 2))
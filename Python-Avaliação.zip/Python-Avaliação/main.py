import funcoes as f
import os

programa = True

os.system("cls")
f.capa()
input()
os.system("cls")

while programa:
    f.menu()
    res = int(input("Escolha uma opção: "))
    match res:
        case 1:
            os.system("cls")
            f.comoJogar()
        case 2:
            f.jogo(False)
        case 3:
            f.jogo(True)
        case 4:
            programa = False  
        case _:
            os.system("cls")
            print("Memo bot XD")

os.system("cls")
    


from colorama import Fore, Style, init
import random
init()

cores = {
    "vermelho": Fore.RED,
    "verde": Fore.GREEN,
    "amarelo": Fore.YELLOW,
    "azul": Fore.BLUE,
    "magenta": Fore.MAGENTA,
    "branco": Fore.WHITE
}

class NaveModelo:
    def __init__(self, nome, dano, simbolo, defesa = 0, velocidade = 0, cor = "branco"):
        self.__nome = nome
        self.__dano = dano
        self.__simbolo = simbolo
        self.__defesa = defesa
        self.__velocidade = velocidade
        self.__cor = "branco"
        
        for i in cores.keys():
            if cor == i:
                self.__cor = cor
                
        self.__energia = 100
        
    @property
    def nome(self):
        return self.__nome
    
    @property
    def cor(self):
        return self.__cor
    
    @property
    def energia(self):
        return self.__energia
    
    @property
    def dano(self):
        return self.__dano
    
    @property
    def simbolo(self):
        return self.__simbolo
    
    @property
    def defesa(self):
        return self.__defesa
    
    @property
    def velocidade(self):
        return self.__velocidade
    
    @energia.setter
    def energia(self, v):
        self.__energia = v
    
    def levardano(self):
        #da dano so se a nave estiver viva
        if self.dano >= self.__energia:
            self.__energia = 0
        else:   
            num1 = random.randint(0, 100)
            #naves com velocidade tem chance de desviar de ataques
            if (num1 > self.__velocidade):
                #naves com defesa vão anular uma percentagem do dano
                self.__energia -= self.__dano * ((100-self.__defesa)/100)
            else:
                print(f"{self.__nome} desviou do ataque!")
        
class Nave(NaveModelo):
    def __init__(self, nome, dano, simbolo, defesa=0, velocidade=0, cor="branco", energiaExtra = 0):
        super().__init__(nome, dano, simbolo, defesa, velocidade, cor)
        self.__energiaExtra = energiaExtra 
        
    @property
    def energiaExtra(self):
        return self.__energiaExtra
    
    #mostrar dados da nave
    def info(self):
        txt = f"Nome: {self.nome}\nEnergia: {self.energia}\nCor: {self.cor}"
        
        print(cores[self.cor] + txt + Style.RESET_ALL)
    
    #adiciona vida extra se a nave estiver viva
    def adicionarExtra(self):
        if self.energia > 0:      
            if self.energia + self.energiaExtra < 100:
                self.energia += self.energiaExtra
            else: 
                self.energia = 100
        else:
            print("nave derrotada")
    
    #transforma a neve num dicionario para guardar o jogo de forma mais facil
    def dicionalizar(self):
        return {
            "nome": self.nome,
            "dano": self.dano,
            "simbolo": self.simbolo,
            "defesa": self.defesa,
            "velocidade": self.velocidade,
            "cor": self.cor,
            "energiaExtra": self.energiaExtra,
            "energia": self.energia
        }
 
#testes       
n3 = Nave("Final.Wonder0", 15, "W", 0, 10, "amarelo", 10)
n3.levardano()
n3.adicionarExtra()
n3.info()

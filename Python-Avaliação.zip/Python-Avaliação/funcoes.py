from tabuleiro import Tabuleiro as t
from naves import Nave as N
from colorama import Fore, Style, init
import json
import os
import random

nome_ficheiro = "dados1.json"

init()
#mostrar capa
def capa():
    print("   <|--NavaDex--|>   ")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("| Jogo desenvolvido |")
    print("|    por: Marcelo   |")
    print("|                   |")
    print("|                   |")
    print("|    Prima enter    |")
    print("|   para começar!   |")
    print("|                   |")
    print(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ ")

#mostra menu
def menu():
    print("     <|--Menu--|>    ")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("| (1)Como jogar.    |")
    print("|                   |")
    print("| (2)Carregar jogo. |")
    print("|                   |")
    print("| (3)Novo Jogo.     |")
    print("|                   |")
    print("| (4)Sair.          |")
    print("|                   |")
    print(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ ")

#tutorial para pessoas novas
def comoJogar():
    print("  <|--ComoJogar--|>  ")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("|(1)Como dar tiros: |")
    print("|                   |")
    print("| Introduza o eixoY |")
    print("| e depois o eixoX. |")
    print("| Exm: '02'ou'14'   |")
    print("|                   |")
    print("|                   |")
    print("|      [Enter]      |")
    print(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ ")
    input()
    os.system("cls")
    
    print("  <|--ComoJogar--|>  ")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("|(1)Game Over:      |")
    print("|                   |")
    print("| Ganhar: Destruir  |")
    print("| todas as naves.   |")
    print("| Perder: Dar 105   |")
    print("| tiros.            |")
    print("|                   |")
    print("|      [Enter]      |")
    print(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ ")
    input()
    os.system("cls")
    
    print("  <|--ComoJogar--|>  ")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("|(1)Salvar:         |")
    print("|                   |")
    print("| Quando terminar,  |")
    print("| salve o jogo para |")
    print("| continuar depois! |")
    print("|                   |")
    print("|Finalizar Tutorial.|")
    print("|      [Enter]      |")
    print(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ ")
    input()
    os.system("cls")
    
#escolher a dificulade do jogo
def jogoInicio():
    os.system("cls")
    print(" <|--Dificuldade--|> ")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("| (1)Facil.         |")
    print("|                   |")
    print("| (2)Casual.        |")
    print("|                   |")
    print("| (3)Expert.        |")
    print("|                   |")
    print("| (4)Mestre.        |")
    print("|                   |")
    print(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ ")

def carregarJogo():
    print(" <|--Carregar Jogo--|> ")
    #função os que vê todos os ficheiros no projeto e coloca numa lista "aux"
    aux = os.listdir(".")
    
    listaFi = []
    #pega so nos ficheiros json e tira e da replace para ficar so o nome e dda apend na listaFi
    for i in aux:
        if ".json" in i:
            a = i.replace(".json", "")
            listaFi.append(a)
       
    #mostra os ficheiros existentes   
    for i in listaFi:
        print(f"File1: {i}")
    res = str(input("Nome do ficheiro: "))
    
    return f"{res}.json"

def infoDados(n1: N, n2: N, n3: N, tirosDados, tirosAcertatos, totalTiros):
    #mostra os dados das naves
        print(Fore.LIGHTGREEN_EX + "______________________" + Style.RESET_ALL)
        print(Fore.LIGHTGREEN_EX + "██ Dados das Naves: ██" + Style.RESET_ALL)
        print(Fore.LIGHTGREEN_EX + "‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾" + Style.RESET_ALL)
        n1.info()
        n2.info()
        n3.info()
        
        #mostrar os dados gerais
        print(Fore.LIGHTGREEN_EX + "______________________" + Style.RESET_ALL)
        print(Fore.LIGHTGREEN_EX + "██ Dados Gerais:    ██" + Style.RESET_ALL)
        print(Fore.LIGHTGREEN_EX + "‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾" + Style.RESET_ALL)
        print(Fore.LIGHTRED_EX + f"Tiros dados: {tirosDados}" + Style.RESET_ALL)
        print(Fore.LIGHTRED_EX + f"Tiros Acerdatos: {tirosAcertatos}" + Style.RESET_ALL)
        print(Fore.LIGHTRED_EX + f"Eficacia: {calcularEficascia(totalTiros, tirosAcertatos)}" + Style.RESET_ALL)
        input()
    
def jogo(novo: bool):
    ficheiroValido = False
    ativo = True
    ganhou = False
    totalTiros = 105
    
    #cria um novo jogo/carrega novo jogo
    if novo:
        energiaExtra = True
        TirosDados = 0
        tirosAcertados = 0
        
        jogoInicio()
        
        res = int(input("Opção: "))
        match res:
            case 1:
                n1 = N("Astro_Proto", 30, "A", 0, 0, "vermelho", 10)
                n2 = N("Jutos_v100", 50, "J", 0, 0, "azul", 20)
                n3 = N("Wonder0", 25, "W", 0, 0, "amarelo", 5)
            case 2:
                n1 = N("Astro_Proto2.0", 30, "A", 10, 0, "vermelho", 15)
                n2 = N("Jutos_v1002.0", 50, "J", 0, 10, "azul", 25)
                n3 = N("Wonder02.0", 25, "W", 0, 5, "amarelo", 10)
            case 3:
                n1 = N("Astro_Proto3.0", 30, "A", 15, 0, "vermelho", 15)
                n2 = N("Jutos_v1003.0", 50, "J", 0, 15, "azul", 25)
                n3 = N("Wonder03.0", 25, "W", 0, 10, "amarelo", 10)
            case 4:
                n1 = N("Final.Astro_Proto", 15, "A", 15, 0, "vermelho", 15)
                n2 = N("Final.Jutos_v100", 25, "J", 0, 15, "azul", 25)
                n3 = N("Final.Wonder0", 15, "W", 0, 10, "amarelo", 10)
        os.system("cls")
        res = str(input("Nome do Jogo: "))
        t1 = t(res)
        ficheiroValido = True
    else: 
        try:
            nome_ficheiro = carregarJogo()
            #carrega os dados do ficheiro
            with open(nome_ficheiro, "r", encoding="utf-8") as f:
                dados = json.load(f)
                ficheiroValido = True
                n1_info = dados["Nave1"]
                n2_info = dados["Nave2"]
                n3_info = dados["Nave3"]
                
                n1 = N(
                    n1_info["nome"],
                    n1_info["dano"],
                    n1_info["simbolo"],
                    n1_info["defesa"],
                    n1_info["velocidade"],
                    n1_info["cor"],
                    n1_info["energiaExtra"]
                )
                
                
                n2 = N(
                    n2_info["nome"],
                    n2_info["dano"],
                    n2_info["simbolo"],
                    n2_info["defesa"],
                    n2_info["velocidade"],
                    n2_info["cor"],
                    n2_info["energiaExtra"]
                )
                
                
                n3 = N(
                    n3_info["nome"],
                    n3_info["dano"],
                    n3_info["simbolo"],
                    n3_info["defesa"],
                    n3_info["velocidade"],
                    n3_info["cor"],
                    n3_info["energiaExtra"]
                )
                
                n1.energia = n1_info["energia"]
                n2.energia = n2_info["energia"]
                n3.energia = n3_info["energia"]
                
                t1 = t(dados["Tabuleiro"]["nome"])
                
                energiaExtra = dados["Dados"]["energiaExtra"]
                TirosDados = dados["Dados"]["TirosDados"]
                tirosAcertados = dados["Dados"]["tirosAcertados"]
                ativo, ganhou = verificarFim(TirosDados, totalTiros, ativo, ganhou, n1, n2, n3)
        except FileNotFoundError:
            os.system("cls")
            print("Ficheiro n existe! Crie um novo jogo!")

    if ficheiroValido:
        while ativo:
            t1.limTabu()
            t1.mostraTabu()
            t1.cargTabuNaves(n1, n2, n3)
            
            tiro1, tiro2, tiro3 = darTiro()
            os.system("cls")
            TirosDados += 3
            
            #mostra o tabuleiro com as naves
            t1.mostraTabu()
            t1.cargTabuTiru(tiro1, tiro2, tiro3)
            tirosAcertados = confirmarTiros(t1, tirosAcertados, n1, n2, n3)
            t1.limTabu()
            
            #mostra o tabuleiro com os tiros
            t1.cargTabuTiru(tiro1, tiro2, tiro3)
            t1.mostraTabu()
            
            #adicionar energia extra
            if TirosDados >=45 and energiaExtra:
                n1.adicionarExtra()
                n2.adicionarExtra()
                n3.adicionarExtra()
                energiaExtra = False
            
            infoDados(n1, n2, n3, TirosDados, tirosAcertados, totalTiros)
            ativo, ganhou = verificarFim(TirosDados, totalTiros, ativo, ganhou, n1, n2, n3)
            
            if(ativo):
                res = int(input("Continuar(1). Salvar e sair(2)"))
                if res == 2:
                    salvarJogo(n1, n2, n3, t1, energiaExtra, TirosDados, tirosAcertados)
                    ativo = False
                    
#ve se os tiros atingiram as naves
def confirmarTiros(tab: t, tirosAc ,n1: N, n2: N, n3: N):
    nova = [item for linha in tab.posicao for item in linha]
    n1Atingido = True
    n2Atingido = True
    n3Atingido = True
    
    #verificação
    for linha in nova:
        if n1.simbolo == linha:
            n1Atingido = False
        elif n2.simbolo == linha:
            n2Atingido = False
        elif n3.simbolo == linha:
            n3Atingido = False
    
    if n1Atingido:
        n1.levardano()
        tirosAc += 1
        
    if n2Atingido:
        n2.levardano()
        tirosAc += 1
        
    if n3Atingido:
        n3.levardano()
        tirosAc += 1
        
    return tirosAc

#verifica se o jogo terminou
def verificarFim(tirosDados: int, totalTiros: int, ativo: bool, ganhou: bool, n1: N, n2: N, n3: N):
    if tirosDados >= totalTiros:
        ativo = False
        ganhou = False
        os.remove(nome_ficheiro)
        print("Perdeu! As naves sobreviveram!")
    elif n1.energia == 0 and n2.energia == 0 and n3.energia == 0:
        ativo = False
        ganhou = True
        os.remove(nome_ficheiro)
        print("Ganhau! Todas as Naves foram destruidas!")
        input()
    
    return ativo, ganhou

#salvar o jogo
def salvarJogo(n1: N, n2: N, n3: N, tab: t, enerEx: bool, tirosDados: int, tirosAce: int):
    dados = {"Nave1": n1.dicionalizar(), "Nave2": n2.dicionalizar(), "Nave3": n3.dicionalizar(), "Tabuleiro": {"nome": tab.nome}, "Dados": {"energiaExtra": enerEx, "TirosDados": tirosDados, "tirosAcertados": tirosAce}}

    x = f"{tab.nome}.json"
    with open(x, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)

#faz o calculo dos tiros.
def calcularEficascia(totaltiros, tirosAcertados):
    return tirosAcertados * 100 / totaltiros

def darTiro():
    res = int(input("Manual(1) ou automatico(2)?: "))
    if res == 1:
        tiro1 = str(input("Tiro1:"))
        tiro2 = str(input("Tiro2:"))
        tiro3 = str(input("Tiro3:"))
    elif res == 2:
        tiro1 = str(random.randint(0, 4)) + str(random.randint(0, 4))
        tiro2 = str(random.randint(0, 4)) + str(random.randint(0, 4))
        
        #certifica que não são iguais
        while tiro2 == tiro1:
            tiro2 = str(random.randint(0, 4)) + str(random.randint(0, 4))
        
        tiro3 = str(random.randint(0, 4)) + str(random.randint(0, 4))
        while tiro3 == tiro1 or tiro3 == tiro2:
            tiro3 = str(random.randint(0, 4)) + str(random.randint(0, 4))
    return tiro1, tiro2, tiro3
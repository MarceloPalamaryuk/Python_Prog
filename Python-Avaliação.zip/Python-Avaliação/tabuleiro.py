import random
from naves import Nave as n
from colorama import Fore, Style, init
init()

class Tabuleiro:
    def __init__(self, nome):
        self.__nome = nome
        self.__posicao = []
    
    @property
    def posicao(self):
        return self.__posicao
    
    @property
    def nome(self):
        return self.__nome
    
    #devolce o valor da posicao
    def getposicao(self, x, y):
        return self.__posicao[x][y]
    
    #limpa o tabuleiro, tudo vira "X"
    def limTabu(self):     
        self.__posicao = []
        
        #o resultado disto vai ser algo assim: [[x,x,x,x,x],[x,x,x,x,x],[x,x,x,x,x],[x,x,x,x,x],[x,x,x,x,x]]
        for i in range(0, 5):
            x = []
            for j in range(0, 5):
                x.append(Fore.YELLOW + "X" + Style.RESET_ALL)
            self.__posicao.append(x)
    
    #colocar as naves nop tabuleiro
    def cargTabuNaves(self, n1: n, n2: n, n3: n):
        #random.randint >>> Numero aleatorio inteiro
        n1X = random.randint(0, 3)
        n1Y = random.randint(0, 3)

        #usar while's para certificar que não tenham posiçoes duplicadas
        n2X = random.randint(0, 4)
        n2Y = random.randint(0, 4)
        while n1X == n2X and n1Y == n2Y:
            n2X = random.randint(0, 4)
            n2Y = random.randint(0, 4)
        
        n3X = random.randint(0, 4)
        n3Y = random.randint(0, 4)        
        while n1X == n3X and n1Y == n3Y or n2X == n3X and n2Y == n3Y:
            n3X = random.randint(0, 4)
            n3Y = random.randint(0, 4)
        
        #muda a posicao a posicao definida pole simbolo da nave se a nave estiver viva
        if n1.energia > 0:
            self.__posicao[n1X][n1Y] = n1.simbolo
        if n2.energia > 0:
            self.__posicao[n2X][n2Y] = n2.simbolo
        if n3.energia > 0:
            self.__posicao[n3X][n3Y] = n3.simbolo
    
        #hack para ver a posiçao das naves durante testes
        print(f"Nave1: y{n1X} x{n1Y}\nNave2: y{n2X} x{n2Y}\nNave3: y{n3X} x{n3Y}")
    
    #colocar tiros no tabuleiro
    def cargTabuTiru(self, t1, t2, t3):
        tiro1 = [int(i) for i in str(t1)]
        tiro2 = [int(i) for i in str(t2)]
        tiro3 = [int(i) for i in str(t3)]
        
        #da cores aos "O"s
        self.__posicao[tiro1[0]][tiro1[1]] = "O"
        self.__posicao[tiro2[0]][tiro2[1]] = "O"
        self.__posicao[tiro3[0]][tiro3[1]] = "O"
    
    # __str__ nada de mais :/
    def __str__(self):
        return f"Nome: {self.__nome}\nPosicao: {self.__posicao}"
    
    #mostra a tabela atual
    def mostraTabu(self):
        cabeca = f" _____________________ \n|███████ Jogo ████████|\n|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|\n|  {Fore.LIGHTBLUE_EX +"0   1   2   3   4 x" + Style.RESET_ALL}|"
        
        corpo = ""
        for i in range(0, 5):
            corpo += f"|{Fore.LIGHTRED_EX + str(i) + Style.RESET_ALL}"
            for j in range(0, 5):
                if j==4:
                    corpo += f"|{self.__posicao[i][j]}|"
                else: corpo += f"|{self.__posicao[i][j]}| "
            corpo += f" |\n"
        corpo += f"|{Fore.LIGHTRED_EX + "y" + Style.RESET_ALL}                    |\n"
        corpo += " ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾ "
        
        print(cabeca)
        print(corpo)
        
#testes
t1 = Tabuleiro("ahh")
t1.limTabu()
t1.cargTabuTiru("00", 11, 22)
t1.mostraTabu()
t1.limTabu()
t1.mostraTabu()




    
    
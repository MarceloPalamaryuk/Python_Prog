def saudacao():
    print("Ola")

def soma(x,y,op):
    if op == "+":
        return x+y    
    elif op == "-":
        return x-y
    elif op == "*":
        return x*y
    else: return x/y
            
######################

def somar(*nums):
    soma = sum([n for n in nums])
    return soma

#print(somar(1,2,3,4,5)) 


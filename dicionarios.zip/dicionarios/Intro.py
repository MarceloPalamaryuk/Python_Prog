import os
aluno = {
    "Nome" : "Marcelo",
    "Natalidade" : "Portugal",
    "Peso" : 87,
    "Altura" : 167,
    "Aprovado" : True
}

#for chave in aluno.keys(): print(chave)

aluno["imc"] = round(aluno["Peso"] / (aluno["Altura"] * aluno["Altura"]),2)
#print(aluno)

d = dict() # dicionario vazio

d1 = dict(nome="Marcelo", idade=16)

d1["idade"] = 17

produtos = {
    "casaco" : {"preco":23,"iva":0.23},
    "camisa" : {"preco":71,"iva":0.13},
    "sapato" : {"preco":55,"iva":0.23}
}

print(sorted(produtos))


d = {n: n+10 for n in range (1,11)}
#print(d)
print(d.values())

aluno = {"matematica": 12, "informatica": 15, "português": 17}
notas = {c: v for c,v in aluno.items() if v >= 15}

nomes = ["Alicate", "Chave de fendas", "Martelo", "Furadeira"]
dict_nomes = {f: len(f) for f in nomes}
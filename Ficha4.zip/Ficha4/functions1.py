import os
import json

nome_ficheiro = "Ficha4\dados1.json"

#ver cenas
def ver_inventario(dados):
    os.system("cls")
    print("___________________________________")
    print("             Inventario            ")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    for k in dados.keys():
        print(f"|{k}||Id: {dados[k]["id"]}|\n|Titulo: {dados[k]["titulo"]}||Autor: {dados[k]["autor"]}|\n|Quantidade: {dados[k]["quantidade"]}||Preco: {dados[k]["preco"]}|\n")
    print("___________________________________")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")

#adicionar cenas :>
def adicionar_item(dados):
    novoItem = { }
    if dados:
        novoId = max(item["id"] for item in dados.values()) + 1
    else:
        novoId = 0
    
    print("___________________________________")
    print("           Adicionar Item          ")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    item_titulo = str(input("Titulo do livro: "))
    item_autor = str(input("Autor do livro: "))
    
    while True:
        item_quantidade = input("Quantidade: ")
        if item_quantidade.isdigit():
            break
        else:
            print("Não pode ser negativo nem decimal, duhh!")

    while True:
        item_preco = round(float(input("Preco: ")), 2)
        if item_preco >= 0:
            break
        else:
            print("Não pode ser negativo, duhh!")
            
    os.system("cls")
    
    nova_chave = f"Livro{novoId + 1}"
    novoItem = {"id": novoId, "titulo": item_titulo, "autor": item_autor, "quantidade": item_quantidade, "preco": item_preco}
    
    dados[nova_chave] = novoItem
    
#mudar a quantidade :P
def atualizar_quantidade(dados, id):
    print("___________________________________")
    print("        Atualizar Quantidade       ")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    while True:
        novaquantidade = input("Quantidade: ")
        if novaquantidade.isdigit():
            break
        else:
            print("Não pode ser negativo nem decimal, duhh!")
    
    chave = f"Livro{id + 1}"
    
    dados[chave]["quantidade"] = novaquantidade

#eliminar item >:(
def eliminar_item(dados, id):
    chave = f"Livro{id+1}"
    res4 = input("<|Tem a certeza? S/N|>")
    if res4.upper() == "S":
        chave = f"Livro{id+1}"
        dados.pop(chave)

#pesquisa avanaçada :V
def pesquisa(dados, pesq):
    negrito = f"\033[1;3;4m{pesq}\033[0m"
    numResultados = 0
    res = ""
    os.system("cls")
    for k in dados.keys():
        if pesq.lower() in dados[k]["autor"].lower() or pesq.lower() in dados[k]["titulo"].lower():            
            res += str((f"|{k}||Id: {dados[k]["id"]}|\n|Titulo: {dados[k]["titulo"].replace(pesq, negrito)}||Autor: {dados[k]["autor"].replace(pesq, negrito)}|\n|Quantidade: {dados[k]["quantidade"]}||Preco: {dados[k]["preco"]}|\n\n"))
            numResultados += 1
    print("___________________________________")
    print("|      ~~~ Resultados ~~~         |")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    print(f"{numResultados} resultados encontrados com:     ")
    print(f"\033[1;3m'{pesq}'\033[0m")
    print(res)
    print("___________________________________")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
  
#calcular o total :O      
def total_inv(dados):
    total = 0.00
    print("___________________________________")
    print("          Valor dos Items          ")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    for k in dados.keys():
        print(f"{k}: {dados[k]["preco"]} (x{dados[k]["quantidade"]}) || {int(dados[k]["quantidade"])*float(dados[k]["preco"])}")
        total += int(dados[k]["quantidade"])*float(dados[k]["preco"])
    print("___________________________________")
    print(f"Total:           || {total}")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
 
def sair(dados, p):
    os.system("cls")
    print("___________________________________")
    print("|         Sair do Programa        |")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    print("(1) Salvar e sair                  ")
    print("(2) Sair sem salvar                ")
    print("(3) Cancelar                       ")
    res3 = int(input("Selecione uma operação: "))
    
    if res3 == 1:
        res4 = input("<|Tem a certeza? S/N|>")
        if res4.upper() == "S":
            with open(nome_ficheiro, "w") as f:
                json.dump(dados, f, indent=4, ensure_ascii=False)
                p = False
                
    elif res3 == 2:
        res4 = input("<|Tem a certeza? Perdera todas as alterações S/N|>")
        if res4.upper() == "S":
            p = False
            
    elif res3 == 3:
        os.system("cls")  
    return p

def menu():
    print("____________________________________")
    print("|>~~~~~~~~~~~<|_MENU_|>~~~~~~~~~~~<|")
    print("|                                  |")
    print("| Selecione uma operação:          |")
    print("|  <(1)|Ver Inventario|>           |")
    print("|  <(2)|Adicionar Item|>           |")
    print("|  <(3)|Atualizar Quantidade|>     |")
    print("|  <(4)|Remover Item|>             |")
    print("|  <(5)|Pesquisa Avançada|>        |")
    print("|  <(6)|Relatório de Stock|>       |")
    print("|  <(7)|Sair|>                     |")
    print("|                                  |")
    print("|>~~~~~~~~~~~<|_MENU_|>~~~~~~~~~~~<|")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")

def salvar(dados):
    with open(nome_ficheiro, "w") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)

def tipoFuncao(tipo):
    if tipo == 3:
        print("___________________________________")
        print("|       Atualizar Quantidade      |")
        print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    elif tipo == 4:
        print("___________________________________")
        print("|          Remover Item           |")
        print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    elif tipo == 5:
        print("___________________________________")
        print("|        Pesquisa Avançada        |")
        print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
        
import os
import json
import functions1
programa_ativo = True

nome_ficheiro = "Ficha4\dados1.json"

#cria um ficheiro se ele não existir
if not os.path.exists(nome_ficheiro):
    with open(nome_ficheiro, "w") as f:
        json.dump({}, f, ensure_ascii=False, indent=4)

#ficheiro json para dicionario O_o
with open(nome_ficheiro, "r") as f:
    dados_livros = json.load(f)

#programa :]  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
while programa_ativo:
    functions1.menu()
    res = int(input("R.: "))
    #resposta errada
    if res > 7 or res < 1:
        os.system("cls")
        print("Es burro ou fazes-te?")
    #ver inventario
    elif res == 1:
        os.system("cls")
        functions1.ver_inventario(dados_livros)
    #adicionar item
    elif res == 2:
        os.system("cls")
        functions1.adicionar_item(dados_livros)
        functions1.salvar(dados_livros)
    #atualizar a quantidade    
    elif res == 3:
        os.system("cls")
        temid=False
        functions1.tipoFuncao(res)
        res1 = int(input("Indique o Id: "))
        os.system("cls")
        
        for k, v in dados_livros.items():
            if res1 == dados_livros[k]["id"]:
                temid=True
                
        if temid:
            functions1.atualizar_quantidade(dados_livros, res1)
            functions1.salvar(dados_livros)
        else:
            print("Id Não existe!")
    #eliminar item
    elif res == 4:
        os.system("cls")
        temid=False
        functions1.tipoFuncao(res)
        res1 = int(input("Indique o Id: "))
        os.system("cls")
        
        for k, v in dados_livros.items():
            if res1 == dados_livros[k]["id"]:
                temid=True
                
        if temid:
            functions1.eliminar_item(dados_livros, res1)
            functions1.salvar(dados_livros)
        else:
            print("Id Não existe!")    
    #pesquisa
    elif res == 5:
        os.system("cls")
        functions1.tipoFuncao(res)
        res2 = str(input("Digite o Autor/Titulo: "))
        functions1.pesquisa(dados_livros, res2)
    #total valor do invntario
    elif res == 6:
        os.system("cls")
        functions1.total_inv(dados_livros)
    #sair do programa
    elif res == 7:
        programa_ativo = functions1.sair(dados_livros, programa_ativo)

#fim do programa
os.system("cls")
f.close()
print("Programa terminou com sucesso!")
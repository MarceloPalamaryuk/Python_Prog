import ComandoTv as C
import Retangulo as R
import Triangulo as T
import os
os.system("cls")

#triangulo
print("|------- Triangulo -------|")
T1 = T.Triangulo(2,2,3)

p = T.Triangulo.perimetro(T1)
T.Triangulo.valido(T1)

print(f"Perimetro: {T.Triangulo.perimetro(T1)}")
print(f"Area: {T.Triangulo.area(T1, p)}")
print(f"Tipo: {T.Triangulo.tipoTriangulo(T1)}")

#Retangulo
print("|------- Retangulo -------|")
R1 = R.Retangulo(4,5, "Preto")
R2 = R.Retangulo(4,5, "Preto")

print(f"Quadrado?: {R.Retangulo.eQuadrado(R1)}")
print(f"Diagonal: {R.Retangulo.diagonal(R1)}")
print(R.Retangulo.msmPerimetro(R1,R2))
print(R.Retangulo.msmCor(R1,R2))

#Comando
print("|------- ComandoTV -------|")

C1 = C.Comando("dantexex", 1900, 5, 10)
C.Comando.mudarCanal(C1, 10)
C.Comando.mudarVolume(C1, True, 30)
C.Comando.mostraDados(C1)

import os

class Comando:
    #conteudo
    def __init__(self, marca, anoFab, canal, volume, on=False):
        self.marca = marca
        self.anoFab = anoFab
        self.canal = canal
        self.volume = volume
        self.on = False
    
    #mudar o canal
    def mudarCanal(self, cana):
        if cana >= 1 and cana <= 99:
            self.canal = cana
    
    #mudar o volume
    def mudarVolume(self, tipo, volume):
        if tipo:
            if self.volume+volume <= 50:
                self.volume = self.volume + volume
            else: self.volume = 50
        else:
            if self.volume-volume >= 0:
                self.volume = self.volume - volume
            else: self.volume = 0
    
    def mute(self):
        self.volume = 0
    
    def onOff(self, tipo):
        self.on = tipo
        if self.on == True:
            return "comando ligado"
        else: return "comando desligado"
    
    #mostrar os dados do com,ando
    def mostraDados(self):
        marc = f"|Marca|> {self.marca}"
        anoF = f"|Ano de Fabricação|> {self.anoFab}"
        can = f"|Canal|> nº{self.canal}"
        vol = f"|Volume|> {self.volume}"
        
        while len(marc) < 33:
            marc += " "
        while len(anoF) < 33:
            anoF += " "
        while len(can) < 33:
            can += " "
        while len(vol) < 33:
            vol += " "

        marc += "|"
        anoF += "|"
        can += "|"
        vol += "|"
        print("|------- Dados do Comando -------|")
        print(marc)
        print(anoF)
        print(can)
        print(vol)
        print("|--------------------------------|")

C1 = Comando("dantexex", 1900, 5, 10)
Comando.mudarVolume(C1, True, 30)
Comando.mostraDados(C1)

import math

class Triangulo:
    def __init__(self, lado1, lado2, lado3):
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3
        self.val = False
        
    
    def valido(self):
        num = 0
        
        if self.lado1 >= self.lado2 + self.lado3:
            num += 1
        elif self.lado2 >= self.lado1 + self.lado3:
            num += 1
        elif self.lado3 >= self.lado1 + self.lado2:
            num += 1
        
        if num == 0:
            self.val = True
        else:
            print("Triangulo não valido.")

    def perimetro(self):
        return self.lado1+self.lado2+self.lado3
    
    def area(self,per):
        p = per/2
        l = p*(p - self.lado1)*(p-self.lado2)*(p-self.lado3)
        return round(math.sqrt(l),2)
    
    def tipoTriangulo(self):
        if (self.lado1 == self.lado2 and self.lado1 == self.lado3):
            return "equilatero"
        elif (self.lado1 != self.lado2 and self.lado2 != self.lado3 and self.lado1 != self.lado3):
            return "escaleno"
        else: return "isósceles"
        
T1 = Triangulo(5, 5, 5)

Triangulo.valido(T1)
p = Triangulo.perimetro(T1)

if T1.val == True:
    print(f"Perimetro: {p}")

area = Triangulo.area(T1, p)
print(area)
print(Triangulo.tipoTriangulo(T1))
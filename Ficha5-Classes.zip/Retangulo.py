import math

class Retangulo:
    def __init__(self, comprimento, largura, cor):
        self.comprimento = comprimento
        self.largura = largura
        self.cor = cor
    
    def eQuadrado(self):
        if self.comprimento == self.largura:
            return "quadrado"
        else: return "não quadrado"
    
    def diagonal(self):
        diagonal = (self.largura) * (self.largura) + (self.comprimento) * (self.comprimento)
        return round(math.sqrt(diagonal), 2)
    
    def msmPerimetro(re1, re2):
        p1 = (re1.comprimento*2)+(re1.largura*2)
        p2 = (re2.comprimento*2)+(re2.largura*2)
        if p1 == p2:
            return "tem o mesmo perimetro!"
        else: return "tem diferentes perimetro!"
    
    def msmCor(ret1, ret2):
        if ret1.cor == ret2.cor:
            return "mesma cor"
        else: return "cores diferentes"
        

R1 = Retangulo(4, 4, "Preto")
R2 = Retangulo(4, 4, "Preto")
print(Retangulo.eQuadrado(R1))
print(Retangulo.diagonal(R1))
print(Retangulo.msmPerimetro(R1,R2))
print(Retangulo.msmCor(R1,R2))

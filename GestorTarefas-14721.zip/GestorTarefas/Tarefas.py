class Trefa:
    def __init__(self, titulo, descricao, data_limite: str):
        self.__titulo = titulo
        self.__descricao = descricao
        self.__data_Limite = data_limite
        self.__concluida = False
    
    def __str__(self):
        msg = f"Titulo: {self.__titulo}\nDescrição: {self.__descricao}\nData Limite: {self.__data_Limite}\nConcluida: "
        if self.__concluida == False:
            msg += "Não"
        else: msg += "Sim"
        return msg
    
    @property
    def titulo(self): return self.__titulo
    @property
    def descricao(self): return self.__descricao
    @property
    def data_limite(self): return self.__data_Limite
    @property
    def concluida(self): return self.__concluida
    
    @titulo.setter
    def titulo(self, v): self.__titulo = v
    @descricao.setter
    def descricao(self, v): self.__descricao = v
    @data_limite.setter
    def data_limite(self, v): self.__data_Limite = v
    @concluida.setter
    def concluida(self, v): self.__concluida = v
    
    
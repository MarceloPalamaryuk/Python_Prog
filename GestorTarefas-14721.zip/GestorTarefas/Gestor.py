import sqlite3
from Tarefas import Trefa as T

class Gestor:
    def __init__(self):
        conn = sqlite3.connect("tarefas.db")
        cursor = conn.cursor()
        
        cursor.execute(
            """
                CREATE TABLE IF NOT EXISTS tarefa_tb(
                    id integer primary key autoincrement,
                    titulo  text not null,
                    descricao text not null,
                    dataLimite text not null,
                    concluida integer not null
                )
            """
        )    
        conn.commit()
        conn.close()
    
    def insert(self, newT: T):
        conn = sqlite3.connect("tarefas.db")
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                "INSERT INTO tarefa_tb(titulo,descricao,dataLimite,concluida) VALUES (?,?,?,?)",
                (newT.titulo, newT.descricao, newT.data_limite, newT.concluida) 
            )
            conn.commit()
            print("Tarefa Inserida!")
        except sqlite3.IntegrityError as e:
            print(f"Erro 01: {e}")
        finally:
            conn.close()
    
    def mostrar(self):
        conn = sqlite3.connect("tarefas.db")
        cursor = conn.cursor()
    
        cursor.execute("SELECT * FROM tarefa_tb")
        tarefas = cursor.fetchall()
        
        if len(tarefas) == 0:
            print("Não existem tarefas.")
        else:
            for tarefa in tarefas:
                aux = "Não"
                if tarefa[4] == 1: aux = "Sim"
                print(f"ID:({tarefa[0]})\nTítulo: {tarefa[1]}\nDescrição: {tarefa[2]}\nDataLimite: {tarefa[3]}\nConcluido: {aux}\n---------------------")
        conn.close()
        
    def marcar(self, id):
        conn = sqlite3.connect("tarefas.db")
        cursor = conn.cursor()
        try:
            cursor.execute("UPDATE tarefa_tb SET concluida = 1 WHERE id = ?", (id,))
            
            if cursor.rowcount == 0:
                print("ID invalido!")
                input("\nPressione enter para continuar...")
            else:
                conn.commit()
                
        except sqlite3.Error as e:
            print(f"Erro02: {e}")
            input("\nPressione enter para continuar...")
        finally:
            conn.close()     
    
    def delete(self, id):
        conn = sqlite3.connect("tarefas.db")
        cursor = conn.cursor()
        
        try:
            cursor.execute("DELETE FROM tarefa_tb WHERE id = ?", (id,))

            if cursor.rowcount == 0:
                print("ID invalido!")
                input("\nPressione enter para continuar...")
            else:
                conn.commit()
            
        except sqlite3.Error as e:
            print(f"Erro03: {e}")
            input("\nPressione enter para continuar...")
        finally:
            conn.close() 

# gestor = Gestor()
# #Tarefa1 = T("Teste1", "Blabla1", "23/01/2025")
# #gestor.insert(Tarefa1)
# gestor.delete(2)
# gestor.mostrar()
from Tarefas import Trefa as t

def menu():
    print("_______________________")
    print("|██/██ TAREFAS++ ██\██|")
    print("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|")
    print("| Selecione uma       |")
    print("| opção!              |")
    print("|---------------------|")
    print("| (1)Adicionar Tarefa |")
    print("|                     |")
    print("| (2)Mostrar Tarefas  |")
    print("|                     |")
    print("| (3)Marcar Tarefa    |")
    print("|                     |")
    print("| (4)Eliminar Tarefa  |")
    print("|                     |")
    print("| (5)Sair             |")
    print("|---------------------|")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    
def adicionar():
    print("_______________________")
    print("|█ █ █ Adicionar █ █ █|")
    print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
    titu = str(input("Titulo: "))
    desc = str(input("Descrição: "))
    DatF = str(input("DataFim: "))
    tarefa = t(titu, desc, DatF)
    return tarefa
import os
from Gestor import Gestor as g
import funcoes as f

gestor = g()
programaAtivo = True

while programaAtivo:
    os.system("cls")
    f.menu()
    res = int(input())
    
    match res:
        case 1:
            os.system("cls")
            tarefa = f.adicionar()
            gestor.insert(tarefa)
        case 2:
            os.system("cls")
            print("_______________________")
            print("| █ ██  TAREFAS  ██ █ |")
            print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
            gestor.mostrar()
            input("\nPressione enter para continuar...")
        case 3:
            os.system("cls")
            print("_______________________")
            print("|██  Marcar Tarefa  ██|")
            print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
            res1 = int(input("ID da tarefa: "))
            gestor.marcar(res1)
        case 4:
            os.system("cls")
            print("_______________________")
            print("|██ Eliminar Tarefa ██|")
            print("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾")
            res2 = int(input("ID da tarefa: "))
            gestor.delete(res2)
        case 5:
            programaAtivo = False
        case _:
            print(";-;")

os.system("cls")
print("Programa finalizado.")
class Naves:
    def __init__(self, nome, cor, dano, simbolo, defesa = 0, velocidade = 0):
        self.__nome = nome
        self.__cor = cor
        self.__energia = 100
        self.__dano = dano
        self.__simbolo = simbolo
        self.__defesa = defesa
        self.__velocidade = velocidade
        
    @property
    def nome(self):
        return self.__nome
    
    @property
    def cor(self):
        return self.__cor
    
    @property
    def energia(self):
        return self.__cor
    
    @property
    def dano(self):
        return self.__dano
    
    @property
    def simbolo(self):
        return self.__simbolo
    
    @property
    def defesa(self):
        return self.__defesa
    
    @property
    def velocidade(self):
        return self.__velocidade
    
    def levardano(self):
        self.__energia -= self.__dano
        
        
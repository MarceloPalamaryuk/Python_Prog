import random

class Tabuleiro:
    def __init__(self, nome):
        self.__nome = nome
        self.__posicao = []
    
    #devolce o valor da posicao
    def posicao(self, x, y):
        return self.__posicao[x][y]
    
    #limpa o tabuleiro, tudo vira "X"
    def limTabu(self):     
        for i in range(0, 5):
            x = []
            for j in range(0, 5):
                x.append("X")
            self.__posicao.append(x)
    
    #colocar as naves nop tabuleiro
    def cargTabuNaves(self, n1, n2, n3):
        #random.randint >>> Numero aleatorio inteiro
        n1X = random.randint(0, 3)
        n1Y = random.randint(0, 3)

        #usar while's para certificar que não tenham posiçoes duplicadas
        n2X = random.randint(0, 4)
        n2Y = random.randint(0, 4)
        while n1X == n2X and n1Y == n2Y:
            n2X = random.randint(0, 4)
            n2Y = random.randint(0, 4)
        
        n3X = random.randint(0, 4)
        n3Y = random.randint(0, 4)        
        while n1X == n3X and n1Y == n3Y or n2X == n3X and n2Y == n3Y:
            n3X = random.randint(0, 4)
            n3Y = random.randint(0, 4)
        
        #muda a posicao a posicao definida pole simbolo da nave
        self.__posicao[n1X][n1Y] = n1
        self.__posicao[n2X][n2Y] = n2
        self.__posicao[n3X][n3Y] = n3
    
    #colocar tiros no tabuleiro
    def cargTabuTiru(self, t1, t2, t3):
        ...
    
    # __str__ nada de mais :/
    def __str__(self):
        return f"Nome: {self.__nome}\nPosicao: {self.__posicao}"
    
    #mostra a tabela atual
    def mostraTabu(self):
        cabeca = " _____________________ \n|   <~> Navadex <~>   |\n|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|\n|  0   1   2   3   4  |"
        
        corpo = ""
        for i in range(0, 5):
            corpo += f"|{i}"
            for j in range(0, 5):
                if j==4:
                    corpo += f"|{self.__posicao[i][j]}|"
                else: corpo += f"|{self.__posicao[i][j]}| "
            corpo += f"{i}|\n"
        corpo += "|_____________________|"
        
        print(cabeca)
        print(corpo)
        
#testes
t1 = Tabuleiro("ahh")
t1.limTabu()
t1.cargTabuNaves("a", "b", "c")
t1.mostraTabu()



    
    